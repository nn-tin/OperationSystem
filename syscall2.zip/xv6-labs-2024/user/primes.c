#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAX 280
#define MIN 2

int generate_natural();
int prime_filter(int in_fd, int prime);

int main(int argc, char *argv[])
{
    int prime;
    int in = generate_natural();
    int pid; // child process ID

    // Continuously read numbers from the current pipe
    // Each first number is a new prime
    while (read(in, &prime, sizeof(int))) {
        printf("prime %d\n", prime);
        in = prime_filter(in, prime);
    }

    // Wait for all child processes to finish to prevent zombies
    while ((pid = wait(0)) > 0) {}

    exit(0);
}

int generate_natural()
{
    int p[2];
    pipe(p); // create a pipe for sending numbers

    if (fork() == 0) { // child process inherits the same file descriptors as parent
        for (int i = MIN; i < MAX; i++)
            write(p[1], &i, sizeof(int)); // write numbers into the pipe

        close(p[1]);  // close write end in child after done writing
        exit(0);      // terminate child process
    }

    close(p[1]); // parent only reads, close write end
    return p[0]; // return read end to be used by main
}

int prime_filter(int in_fd, int prime)
// Close the old read file descriptor (in_fd)
// Return the new read end of a pipe that contains filtered numbers
{
    int p[2];
    pipe(p); // create a new pipe to store numbers after filtering

    if (fork() == 0) {
        int i; // temporary variable for current number

        // Read numbers from input pipe
        // Write numbers that are not multiples of 'prime' to the new pipe
        while (read(in_fd, &i, sizeof(int)))
            if (i % prime != 0)
                write(p[1], &i, sizeof(int));

        close(in_fd); // close read end (no longer needed)
        close(p[1]);  // close write end after finishing
        exit(0);
    }

    close(in_fd); // parent no longer needs the old read end
    close(p[1]);  // parent does not write to the new pipe
    return p[0];  // return read end of the new pipe
}
