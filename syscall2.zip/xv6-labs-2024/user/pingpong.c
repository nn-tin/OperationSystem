#include "kernel/types.h"
#include "user/user.h"

int main(){
    int p2c[2]; 
    int c2p[2];

    if (pipe(p2c) < 0 || pipe(c2p) < 0) {
        printf("ping error");
        exit(1);
    }

    int forked = fork();

    if(forked < 0 ){
        printf("fork error");
        exit(1);
    }

    if(forked == 0){
        // === CHILDRREN=====

        // NHẬN 1 BYTE TỪ CHA
        close(p2c[1]); close(c2p[0]);

        char b;
        if(read(p2c[0], &b, 1) != 1){
            exit(1); // error
        }
        printf("%d: received ping\n", getpid());

        // GỬI 1 BYTE SANG CHA
        if(write(c2p[1], &b, 1) != 1){
            exit(1); // error
        }

        close(c2p[1]);
        close(p2c[0]);
        exit(0);

    }  else {
        // === PARENT=====
        // NHẬN 1 BYTE TỪ CON
        close(p2c[0]); close(c2p[1]);

        
        // GỬI 0 BYTE SANG CHA
        char b = 'A';
        if(write(p2c[1], &b, 1) != 1){
            exit(1); // error
        }

        if(read(c2p[0], &b, 1) != 1){
            exit(1); // error
        }
        printf("%d: received pong\n", getpid());

        
        close(c2p[0]);
        close(p2c[1]);
        exit(0);
    }
    
}