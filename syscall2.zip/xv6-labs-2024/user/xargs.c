#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAX_ARGS 10
#define MAX_LEN 512

int main(int argc, char* argv[])
{
    if (argc < 2) {
        printf("Usage: xargs <command> [args...]\n");
        exit(1);
    }

    char* cmd[MAX_ARGS];
    int base = 0, n;
    for (int i = 1; i < argc && i < MAX_ARGS - 1; i++) {
        cmd[base++] = argv[i];
    }

    char buf[MAX_LEN];
    while ((n = read(0, buf, sizeof(buf) - 1)) > 0) { //read stdin into buffer
        buf[n] = '\0';
        char* p = buf;
        char* newline;
        while ((newline = strchr(p, '\n')) != 0) { //newline point to the next '\n' and check if it's the end
            *newline = '\0';
            cmd[base] = p;
            cmd[base + 1] = '\0';

            if (fork() == 0) {
                exec(cmd[0], cmd);
                printf("xargs: exec %s failed\n", cmd[0]);
                exit(1);
            }
            wait(0);

            p = newline + 1;
        }
    }

    exit(0);
}
