#include "kernel/types.h"
#include "user/user.h"
#include "kernel/stat.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

// --- Hàm trợ giúp ---
// Lấy tên file từ một đường dẫn (ví dụ: "a/b/c.txt" -> "c.txt")
char* fmtname(char *path)
{
    char *p;

    // Tìm ký tự '/' cuối cùng
    for(p=path+strlen(path); p >= path && *p != '/'; p--)
        ;
    p++; // p bây giờ trỏ đến ký tự ngay sau dấu '/'
    
    // Trả về con trỏ đến tên file
    return p;
}


void find(char* current_path, char* target_name){
    // fprintf(2, "SEARCH: %s %s\n", current_path, target_name); // Dòng debug 
    char buf[512], *p; 
    int fd;
    struct dirent de;
    struct stat st;

    if((fd = open(current_path, O_RDONLY)) < 0){
        fprintf(2, "find: cannot open %s\n", current_path);
        return;
    }

    if(fstat(fd, &st) < 0){
        fprintf(2, "find: cannot stat %s\n", current_path);
        close(fd);
        return;
    }

    switch(st.type){
        case T_DEVICE:
        case T_FILE:
            //Chỉ so sánh tên file, không so sánh toàn bộ đường dẫn
            if(strcmp(fmtname(current_path), target_name) == 0){
                printf("%s\n", current_path); // In ra đường dẫn đầy đủ
            }
            break; // Lệnh break này đã có và đúng

        case T_DIR:
            if(strlen(current_path) + 1 + DIRSIZ + 1 > sizeof buf){
                printf("find: path too long\n"); // Sửa lại thông báo lỗi
                break;
            }

            strcpy(buf, current_path); // Copy đường dẫn hiện tại vào buf
            p = buf+strlen(buf);
            *p++ = '/'; // Thêm dấu '/' vào cuối và di chuyển con trỏ p

            while(read(fd, &de, sizeof(de)) == sizeof(de)){
                if(de.inum == 0){
                    continue;
                }

                //Bỏ qua "." và ".." một cách rõ ràng
                if(strcmp(de.name, ".") == 0 || strcmp(de.name, "..") == 0){
                    continue;
                }

                // de.name là một string, nên dùng strcpy
                strcpy(p, de.name);

                // buf bây giờ là đường dẫn đầy đủ đến file/thư mục con
                // (ví dụ: "dir1/file.txt" hoặc "dir1/subdir")

                // Gọi đệ quy find() cho đường dẫn mới này
                // Nó sẽ tự xử lý dù buf là file hay thư mục
                find(buf, target_name);
            }
            
            break; 
    }
    close(fd); // Đóng file descriptor
}

int main(int argc, char* argv[]){
    if(argc != 3){

        printf("usage: find {directory} {filename}\n");
        exit(1);
    }

    find(argv[1], argv[2]);
    exit(0);
}